
from django.contrib import admin
from django.urls import path,include
from home import views
from features.views import *
app_name='basic'
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.log,name='log'),
    path('register/',views.Reg,name="reg"),
    path('logout/',views.logout,name="logout"),
    path('logout/',views.logout,name="logout"),
    path('cancel_reservation/(<int:pid>)',cancel_reservation,name="cancel_reservation"),
    path('edit_profile/',edit_profile,name="edit_profile"),
    path('change_password/',Change_Password,name="change_password"),
    path('home/',include('home.urls',namespace="home"),name="home"),
    path('features/',include('features.urls',namespace="features"),name="features"),

]
