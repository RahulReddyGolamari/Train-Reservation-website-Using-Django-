from django.urls import path
from django.contrib import admin

from .views import *
app_name='features'
urlpatterns = [
    path('cancel_reservation/(<int:pid>)',cancel_reservation,name="cancel_reservation"),
]

